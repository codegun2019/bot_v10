<?php

/* Load all the related plugin files */
require_once \Altum\Plugin::get('payment-blocks')->path . 'PaymentBlocks.php';
