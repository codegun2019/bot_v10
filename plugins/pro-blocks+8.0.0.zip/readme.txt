💻 How to install

You simply need to download the files, unzip the package and then copy the "pro-blocks" folder inside of your plugins folder of the main product installation.

After that, you can go inside of your admin panel, go to the Plugins management section and enable your new plugin.